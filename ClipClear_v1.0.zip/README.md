# ClipClear
 Utility for Clearing Clipboard

Author: Matthew Russell
Contact: Matthew.Russell@boujeesoft.com
Website: ScriptedAdventures.net


Run the InstallClipClear.bat file as an Administrator to install utility. 
After Install, locate in start menu and pin to taskbar for easy use
If you wish to uninstall, navigate to C:\ProgramData\ClipClear and run the UninstallClipClear.bat file, then delete the ClipClear folder. 



Thanks!